# Jenkins-.NET-Core-CI-CD-pipeline

[Jenkins with .NET Core CI&CD pipeline for Linux tutorial](https://voltwu.github.io/blog/jenkins/2020/12/30/Jenkins-with-asp-net-core-CI-CD-pipeline-for-linux/)
